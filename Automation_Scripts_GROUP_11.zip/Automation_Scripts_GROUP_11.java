@Test
void deleteUser_UserNotFoundAfterRetries_ReturnsNotFound() {
    // Mocking the behavior of the encryption utility service to simulate that the authorization is successful.
    when(encryptionUtilsService.isAuthorized(anyString())).thenReturn(true);

    // Using try-with-resources to mock the static method of CsvManagerService. 
    // This allows mocking the deleteUserByKey method to simulate a "user not found" scenario.
    try (MockedStatic<CsvManagerService> mockedCsvService = Mockito.mockStatic(CsvManagerService.class)) {
        
        // Mocking the static method deleteUserByKey to return false, 
        // which simulates that no user was found for the given key "nonexistentUser".
        mockedCsvService.when(() -> CsvManagerService.deleteUserByKey("nonexistentUser"))
                .thenReturn(false);

        // Calling the deleteUser method of the controller with a nonexistent username.
        // This simulates the scenario where the user trying to be deleted does not exist in the system.
        ResponseEntity<String> response = adminRestController.deleteUser("nonexistentUser", "validKey");

        // Asserting that the response status code is NOT_FOUND (404).
        // This is expected since the user does not exist in the database.
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

        // Asserting that the response body contains the expected message indicating the user was not found.
        assertTrue(response.getBody().contains("User with key nonexistentUser not found"));
    }
}

//Test case number 2
@Test
void testHandleLogin_SuccessfulLogin() {
    // Test data setup: valid login details
    String username = "admin";
    String password = "expectedPassword";
    String captchaId = "captcha123";
    String captcha = "validCaptcha";

    // Mocking the request's remote address to simulate the user's IP address
    when(request.getRemoteAddr()).thenReturn("127.0.0.1");

    // Mocking the captcha service to simulate that the captcha is valid
    when(captchaService.verifyCaptcha(captchaId, captcha)).thenReturn(true);

    // Mocking the userSecurity object to simulate that the user is not locked out
    UserSecurity userSecurity = mock(UserSecurity.class);
    when(userSecurity.isLockedOut()).thenReturn(false);
    when(userSecurityService.getUserSecurity(any(User.class))).thenReturn(userSecurity);

    // Mocking the configuration file to simulate that it contains the correct username and password
    List<String[]> mockConfig = new ArrayList<>();
    mockConfig.add(new String[]{"key", "value"}); // Adding some mock configuration data
    mockConfig.add(new String[]{"admin", "expectedPassword"}); // The admin username and expected password
    when(CsvManagerService.getConfiguration()).thenReturn(mockConfig);

    // Mocking the encryption utility service to simulate password encryption
    when(encryptionUtilsService.encrypt(password)).thenReturn("encryptedPassword");

    // Calling the handleLogin method with the test data to simulate a successful login
    ResponseEntity<Map<String, String>> response = adminLoginController.handleLogin(username, password, captchaId, captcha, request);

    // Asserting that the response status code is 200 (OK), indicating a successful login
    assertEquals(200, response.getStatusCodeValue());

    // Asserting that the response contains the 'Set-Cookie' header, indicating session creation or token issuance
    assertTrue(response.getHeaders().containsKey(HttpHeaders.SET_COOKIE));

    // Asserting that the response body contains a redirect URL to the admin page after a successful login
    assertEquals("/admin", response.getBody().get("redirect"));

    // Verifying that the successful login handler method was called on the userSecurityService
    verify(userSecurityService).handleSuccessfulLogin(any(User.class));
}



//Test case Number 3
@Test
void testAddUser_Authorized() throws CsvValidationException, IOException {
    // Mocking the encryption service to return 'true' for the authorization check with a valid key
    when(encryptionUtilsService.isAuthorized("validKey")).thenReturn(true);

    // Mocking the CsvManagerService to return 'false' indicating that the user 'newUser' does not already exist
    when(CsvManagerService.userExists("newUser")).thenReturn(false);

    // Calling the 'add' method from the adminUsersController, passing valid authorization key, user, and token
    ModelAndView modelAndView = adminUsersController.add("validKey", "newUser", "token", redirectAttributes);

    // Asserting that the view name returned is a redirect to the 'admin/users' page
    assertEquals("redirect:/admin/users", modelAndView.getViewName());

    // Verifying that the redirectAttributes method 'addFlashAttribute' was called to add a success message
    verify(redirectAttributes).addFlashAttribute("message", "User added successfully.");

    // Verifying that the CsvManagerService's 'addUser' method is called to actually add the new user
    verify(csvManagerService);
    CsvManagerService.addUser("newUser", "token");
}
