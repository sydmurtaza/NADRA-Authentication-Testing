package com.boot.example.boot.controller;

import com.boot.example.boot.services.CaptchaService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

@RestController
@RequestMapping("/captcha")
public class CaptchaController {

  private final CaptchaService captchaService;

  public CaptchaController(CaptchaService captchaService) {
    this.captchaService = captchaService;
  }

  @GetMapping("/generate")
  public ResponseEntity<byte[]> generateCaptcha() {
    try {
      // Generate CAPTCHA text and ID
      String captchaText = captchaService.generateCaptchaText();
      String captchaId = captchaService.storeCaptcha(captchaText);

      // Generate CAPTCHA image and convert to byte array
      BufferedImage captchaImage = captchaService.generateCaptchaImage(captchaText);
      byte[] imageBytes = convertImageToByteArray(captchaImage);

      // Set response headers with CAPTCHA ID
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.IMAGE_PNG);
      headers.add("Captcha-ID", captchaId);

      // Return CAPTCHA image with headers
      return ResponseEntity.ok()
          .headers(headers)
          .body(imageBytes);
    } catch (IOException e) {
      // Log and handle image generation error
      return handleError("Error generating CAPTCHA image.");
    }
  }

  @PostMapping("/verify")
  public ResponseEntity<String> verifyCaptcha(
      @RequestParam("captchaId") String captchaId,
      @RequestParam("captcha") String captcha) {

    boolean isValid = captchaService.verifyCaptcha(captchaId, captcha);
    if (isValid) {
      return ResponseEntity.ok("CAPTCHA verified successfully.");
    } else {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid CAPTCHA.");
    }
  }

  private byte[] convertImageToByteArray(BufferedImage image) throws IOException {
    try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
      ImageIO.write(image, "png", baos);
      return baos.toByteArray();
    }
  }

  private ResponseEntity<byte[]> handleError(String errorMessage) {
    // Log the error
    // (Assuming a logger is available, otherwise you can use a logging framework or
    // remove this line)
    System.err.println(errorMessage);
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
        .body(errorMessage.getBytes());
  }
}