package com.boot.example.boot.services;

import org.springframework.stereotype.Service;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import javax.imageio.ImageIO;

@Service
public class CaptchaService {

  private static final int CAPTCHA_LENGTH = 5;
  private static final String CAPTCHA_CHARS = "0123456789";

  private final ConcurrentHashMap<String, String> captchaStore = new ConcurrentHashMap<>();

  // Method to generate random CAPTCHA text
  public String generateCaptchaText() {
    StringBuilder captchaText = new StringBuilder(CAPTCHA_LENGTH);
    Random random = new Random();
    for (int i = 0; i < CAPTCHA_LENGTH; i++) {
      captchaText.append(CAPTCHA_CHARS.charAt(random.nextInt(CAPTCHA_CHARS.length())));
    }
    return captchaText.toString();
  }

  // Method to generate a professional CAPTCHA image
  public BufferedImage generateCaptchaImage(String captchaText) {
    int width = 200;
    int height = 50;

    BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    Graphics2D g2d = bufferedImage.createGraphics();

    g2d.fillRect(0, 0, width, height);

    // Set anti-aliasing for smoother text
    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

    // Draw text in a modern, clean font
    g2d.setColor(Color.BLACK);
    g2d.setFont(new Font("Arial", Font.BOLD, 37));

    g2d.drawString(captchaText, 40, height / 2 + 10);

    // Optional shadow for text to make it stand out
    g2d.setColor(new Color(0, 0, 0, 50));
    g2d.drawString(captchaText, 42, height / 2 + 12);

    g2d.dispose();
    return bufferedImage;
  }

  // Method to store CAPTCHA text and return ID
  public String createCaptcha() {
    String captchaText = generateCaptchaText();
    return storeCaptcha(captchaText);
  }

  // Method to store CAPTCHA text and return ID
  public String storeCaptcha(String captchaText) {
    String captchaId = generateCaptchaId();
    captchaStore.put(captchaId, captchaText);
    return captchaId;
  }

  // Method to verify the input CAPTCHA
  public boolean verifyCaptcha(String captchaId, String inputCaptcha) {
    String actualCaptcha = captchaStore.get(captchaId);
    return actualCaptcha != null && actualCaptcha.equals(inputCaptcha);
  }

  // Method to generate a unique ID for each CAPTCHA
  private String generateCaptchaId() {
    return String.valueOf(System.currentTimeMillis());
  }

  // Method to get CAPTCHA image as Base64 string
  public String getCaptchaImageBase64(String captchaId) {
    String captchaText = captchaStore.get(captchaId);
    if (captchaText == null) {
      return null;
    }

    BufferedImage captchaImage = generateCaptchaImage(captchaText);

    try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
      ImageIO.write(captchaImage, "png", baos);
      byte[] imageBytes = baos.toByteArray();
      return Base64.getEncoder().encodeToString(imageBytes);
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    }
  }
}
