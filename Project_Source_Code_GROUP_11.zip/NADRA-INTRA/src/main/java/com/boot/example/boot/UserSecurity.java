package com.boot.example.boot;

import java.time.LocalDateTime;

public class UserSecurity {

    // Constants for security settings
    private static final int MAX_FAILED_ATTEMPTS_BEFORE_SHORT_LOCK = 2; // Lock after 3 failed attempts
    private static final int SHORT_LOCK_DURATION_SECONDS = 60;

    // Fields to track failed attempts and lockout times
    private int failedAttempts = 0;
    private LocalDateTime lockoutEndTime = null;
    private int otpFailedAttempts = 0;
    private LocalDateTime otpLockoutEndTime = null;
    private final String email;

    public UserSecurity(String email) {
        this.email = email;
    }

    // Getter methods
    public int getFailedAttempts() {
        return failedAttempts;
    }

    public LocalDateTime getLockoutEndTime() {
        return lockoutEndTime;
    }

    public int getOtpFailedAttempts() {
        return otpFailedAttempts;
    }

    public LocalDateTime getOtpLockoutEndTime() {
        return otpLockoutEndTime;
    }

    public String getEmail() {
        return email;
    }

    // Methods to check if the user is locked out
    public boolean isLockedOut() {
        return lockoutEndTime != null && lockoutEndTime.isAfter(LocalDateTime.now());
    }

    public boolean isOtpLockedOut() {
        return otpLockoutEndTime != null && otpLockoutEndTime.isAfter(LocalDateTime.now());
    }

    // Method to handle failed attempts (both login and OTP)
    private void handleFailedAttempt(boolean isLoginAttempt) {
        if (isLoginAttempt) {
            failedAttempts++;

            // Lock the account on the 3rd failed attempt
            if (failedAttempts >= MAX_FAILED_ATTEMPTS_BEFORE_SHORT_LOCK) {
                lockoutEndTime = LocalDateTime.now().plusSeconds(SHORT_LOCK_DURATION_SECONDS);
                failedAttempts = 0; // Reset failed attempts after lockout is set
            }
        } else {

            otpFailedAttempts++;

            // Lock the account on the 3rd failed OTP attempt
            if (otpFailedAttempts >= MAX_FAILED_ATTEMPTS_BEFORE_SHORT_LOCK) {
                otpLockoutEndTime = LocalDateTime.now().plusSeconds(SHORT_LOCK_DURATION_SECONDS);
                otpFailedAttempts = 0; // Reset failed attempts after lockout
            }
        }
    }

    // Public methods to handle failed and successful login attempts
    public void handleFailedLogin() {
        handleFailedAttempt(true);
    }

    public void handleSuccessfulLogin() {
        resetFailedLoginAttempts();
    }

    // Public methods to handle failed and successful OTP attempts
    public void handleFailedOtp() {
        handleFailedAttempt(false);
    }

    public void handleSuccessfulOtp() {
        resetFailedOtpAttempts();
    }

    // Private methods to reset failed attempts
    private void resetFailedLoginAttempts() {
        failedAttempts = 0;
        lockoutEndTime = null;
    }

    private void resetFailedOtpAttempts() {
        otpFailedAttempts = 0;
        otpLockoutEndTime = null;
    }
}
