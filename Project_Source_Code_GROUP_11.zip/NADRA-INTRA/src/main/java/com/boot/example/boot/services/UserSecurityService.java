package com.boot.example.boot.services;

import com.boot.example.boot.User;
import com.boot.example.boot.UserSecurity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Service
public class UserSecurityService {

    private static final Logger logger = LoggerFactory.getLogger(UserSecurityService.class);
    private final ConcurrentMap<String, UserSecurity> userSecurityMap = new ConcurrentHashMap<>();

    public UserSecurity getUserSecurity(User user) {
        return userSecurityMap.computeIfAbsent(user.getEmail(), k -> {
            logger.info("Creating new UserSecurity instance for user: {}", user.getEmail());
            return new UserSecurity(user.getEmail());
        });
    }

    public void handleFailedLogin(User user) {
        UserSecurity userSecurity = getUserSecurity(user);
        userSecurity.handleFailedLogin();
        logger.warn("Failed login attempt for user: {}. Failed attempts: {}", user.getEmail(),
                userSecurity.getFailedAttempts());

        // Log the current lockout status for debugging
        if (userSecurity.isLockedOut()) {
            logger.warn(
                    "Account locked for user: {}. Lockout message: Account is locked for 60 seconds. Please try again later.",
                    user.getEmail());
        }
    }

    public void handleSuccessfulLogin(User user) {
        UserSecurity userSecurity = getUserSecurity(user);
        userSecurity.handleSuccessfulLogin();
        logger.info("Successful login for user: {}", user.getEmail());
    }

    public boolean isUserLockedOut(User user) {
        UserSecurity userSecurity = getUserSecurity(user);
        boolean lockedOut = userSecurity.isLockedOut();
        logger.info("User: {} is {}locked out.", user.getEmail(), lockedOut ? "" : "not ");
        return lockedOut;
    }

    public void handleFailedOtp(User user) {
        UserSecurity userSecurity = getUserSecurity(user);
        userSecurity.handleFailedOtp();
        logger.warn("Failed OTP attempt for user: {}. Failed OTP attempts: {}", user.getEmail(),
                userSecurity.getOtpFailedAttempts());

        // Log the current OTP lockout status for debugging
        if (userSecurity.isOtpLockedOut()) {
            logger.warn(
                    "OTP locked out for user: {}. Lockout message: OTP is locked for 60 seconds. Please try again later.",
                    user.getEmail());
        }
    }

    public void handleSuccessfulOtp(User user) {
        UserSecurity userSecurity = getUserSecurity(user);
        userSecurity.handleSuccessfulOtp();
        logger.info("Successful OTP for user: {}", user.getEmail());
    }

    public boolean isOtpLockedOut(User user) {
        UserSecurity userSecurity = getUserSecurity(user);
        boolean otpLockedOut = userSecurity.isOtpLockedOut();
        logger.info("User: {} is {}OTP locked out.", user.getEmail(), otpLockedOut ? "" : "not ");
        return otpLockedOut;
    }
}
