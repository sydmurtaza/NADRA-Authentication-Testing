package com.boot.example.boot.controller.admin;

import com.boot.example.boot.services.CsvManagerService;
import com.boot.example.boot.services.EncryptionUtilsService;
import com.opencsv.exceptions.CsvValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Controller
public class AdminUsersController {

    private static final Logger logger = LoggerFactory.getLogger(AdminUsersController.class);
    private static final String REDIRECT_LOGIN = "redirect:/admin/login";
    private static final String REDIRECT_USERS = "redirect:/admin/users";
    private static final String REDIRECT_CONFIG = "redirect:/admin/config";
    private static final String CONFIG_PAGE = "admin/configForm";
    private static final String USER_PAGE = "admin/users/index";
    private static final String ADMIN_INDEX_PAGE = "admin/index";
    private static final String NEW_USER_FORM_PAGE = "admin/users/new";

    private final EncryptionUtilsService encryptionUtilsService;

    public AdminUsersController(EncryptionUtilsService encryptionUtilsService) {
        this.encryptionUtilsService = encryptionUtilsService;
    }

    @GetMapping("/admin/users")
    public String getIndex(Model model, @CookieValue(name = "key", required = false) String encryptedKey) {
        logger.info("Received GET request for admin users page. Cookie key (masked): {}",
                maskSensitiveData(encryptedKey));

        if (!isAuthorized(encryptedKey)) {
            return REDIRECT_LOGIN;
        }

        Map<String, String> usersMap = CsvManagerService.getAllUsers();
        model.addAttribute("usersMap", usersMap);
        logger.info("Successfully retrieved users for admin users page.");
        return USER_PAGE;
    }

    @GetMapping("/admin/config")
    public String getConfig(Model model, @CookieValue(name = "key", required = false) String encryptedKey) {
        logger.info("Received GET request for admin config page. Cookie key (masked): {}",
                maskSensitiveData(encryptedKey));

        if (!isAuthorized(encryptedKey)) {
            logger.warn("Unauthorized access attempt for admin config page with cookie key: {}",
                    maskSensitiveData(encryptedKey));
            return REDIRECT_LOGIN;
        }

        try {
            List<String> configurations = fetchConfigurations();
            model.addAttribute("configurations", configurations);
            logger.info("Successfully retrieved configuration for admin config page.");
            return CONFIG_PAGE;
        } catch (Exception e) {
            logger.error("Error retrieving configuration for admin config page", e);
            return REDIRECT_LOGIN;
        }
    }

    @PostMapping("/admin/config")
    @ResponseBody
    public ModelAndView update(@CookieValue(name = "key", required = false) String encryptedKey,
            @RequestParam String principalName,
            @RequestParam String ldapUrl,
            @RequestParam String domain,
            @RequestParam String exchangeIp,
            @RequestParam String password,
            RedirectAttributes redirectAttributes) {
        logger.info("Received POST request to update configuration. Cookie key (masked): {}",
                maskSensitiveData(encryptedKey));

        if (!isAuthorized(encryptedKey)) {
            logger.warn("Unauthorized attempt to update configuration with cookie key: {}",
                    maskSensitiveData(encryptedKey));
            return new ModelAndView(REDIRECT_LOGIN);
        }

        try {
            CsvManagerService.updateConfiguration(principalName, ldapUrl, domain, exchangeIp, password);
            redirectAttributes.addFlashAttribute("message", "Configuration updated successfully.");
            logger.info("Configuration updated successfully.");
        } catch (Exception e) {
            logger.error("Failed to update configuration", e);
            redirectAttributes.addFlashAttribute("error", "Failed to update configuration: " + e.getMessage());
        }

        return new ModelAndView(REDIRECT_CONFIG);
    }

    @PostMapping("/admin/user")
    @ResponseBody
    public ModelAndView add(@CookieValue(name = "key", required = false) String encryptedKey,
            @RequestParam String username,
            @RequestParam String token,
            RedirectAttributes redirectAttributes) throws CsvValidationException, IOException {
        logger.info("Received POST request to add user. Username: {}. Cookie key (masked): {}", username,
                maskSensitiveData(encryptedKey));

        if (!isAuthorized(encryptedKey)) {
            logger.warn("Unauthorized attempt to add user {} with cookie key: {}", username,
                    maskSensitiveData(encryptedKey));
            redirectAttributes.addFlashAttribute("message", "User not authorized.");
            return new ModelAndView(REDIRECT_LOGIN);
        }

        if (CsvManagerService.userExists(username)) {
            logger.info("User {} already exists.", username);
            redirectAttributes.addFlashAttribute("message", "User already exists.");
            return new ModelAndView(REDIRECT_USERS);
        }

        try {
            CsvManagerService.addUser(username, token);
            redirectAttributes.addFlashAttribute("message", "User added successfully.");
            logger.info("User {} added successfully.", username);
        } catch (Exception e) {
            logger.error("Error adding user {}", username, e);
            redirectAttributes.addFlashAttribute("message", "Error adding user: " + e.getMessage());
        }

        return new ModelAndView(REDIRECT_USERS);
    }

    @GetMapping("/admin")
    public String getAdminIndex(@CookieValue(name = "key", required = false) String encryptedKey, Model model) {
        logger.info("Received GET request for admin index page. Cookie key (masked): {}",
                maskSensitiveData(encryptedKey));

        if (!isAuthorized(encryptedKey)) {
            return REDIRECT_LOGIN;
        }

        Map<String, String> usersMap = CsvManagerService.getAllUsers();
        model.addAttribute("usersMap", usersMap);
        logger.info("Successfully retrieved users for admin index page.");
        return ADMIN_INDEX_PAGE;
    }

    @GetMapping("/admin/user")
    public String newUserForm(@CookieValue(name = "key", required = false) String encryptedKey) {
        logger.info("Received GET request for new user form. Cookie key (masked): {}", maskSensitiveData(encryptedKey));

        if (isAuthorized(encryptedKey)) {
            logger.info("Authorized access to new user form.");
            return NEW_USER_FORM_PAGE;
        }

        return REDIRECT_LOGIN;
    }

    private boolean isAuthorized(String encryptedKey) {
        boolean authorized = encryptionUtilsService.isAuthorized(encryptedKey);
        if (!authorized) {
            logger.warn("Unauthorized access attempt with cookie key: {}", maskSensitiveData(encryptedKey));
        }
        return authorized;
    }

    private List<String> fetchConfigurations() throws CsvValidationException, IOException {
        List<String[]> data = CsvManagerService.getConfiguration();
        return Arrays.asList(
                data.get(0)[1],
                data.get(1)[1],
                data.get(2)[1],
                data.get(3)[1]);
    }

    private String maskSensitiveData(String data) {
        return (data == null || data.isEmpty()) ? "N/A" : "****"; // Masked data for security
    }
}
