package com.boot.example.boot.controller;

import com.boot.example.boot.User;
import com.boot.example.boot.UserSecurity;
import com.boot.example.boot.services.CaptchaService;
import com.boot.example.boot.services.CsvManagerService;
import com.boot.example.boot.services.EncryptionUtilsService;
import com.boot.example.boot.services.OtpService;
import com.boot.example.boot.services.UserSecurityService;
import com.warrenstrange.googleauth.GoogleAuthenticator;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import java.time.Duration;
import java.util.Hashtable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class LoginController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

    private final EncryptionUtilsService encryptionUtilsService;
    private final CaptchaService captchaService;
    private final UserSecurityService userSecurityService;
    private final OtpService otpService;

    private String ldapUrl;
    private String principalName;
    private String domain;
    private DirContext ldapContext;

    public LoginController(EncryptionUtilsService encryptionUtilsService, CaptchaService captchaService,
            UserSecurityService userSecurityService, OtpService otpService) {
        this.encryptionUtilsService = encryptionUtilsService;
        this.captchaService = captchaService;
        this.userSecurityService = userSecurityService;
        this.otpService = otpService;
        loadLdapConfiguration();
        // initializeLdapContext();
    }

    @GetMapping("/login")
    public String showLoginPage() {
        LOGGER.info("Accessing login page.");
        return "loginForm";
    }

    @GetMapping("/")
    public String redirectToLogin() {
        LOGGER.info("Redirecting to login page.");
        return "redirect:/login";
    }

    @GetMapping("/autoLogin")
    public String autoLogin(@CookieValue(name = "username", required = true) String encryptedUsername,
            @CookieValue(name = "password", required = true) String encryptedPassword,
            @CookieValue(name = "exchangeIp", required = true) String encryptedExchangeIp,
            Model model) {
        // Decrypt the username, password, and exchangeIp
        String username = encryptionUtilsService.decrypt(encryptedUsername);
        String password = encryptionUtilsService.decrypt(encryptedPassword);
        String exchangeIp = encryptionUtilsService.decrypt(encryptedExchangeIp);

        // Add the decrypted parameters to the model
        model.addAttribute("username", username);
        model.addAttribute("password", password);
        model.addAttribute("exchangeIp", exchangeIp);

        // Return the name of the Thymeleaf template (autoLogin.html)
        return "autoLogin";
    }

    @PostMapping("/login")
    @ResponseBody
    public ResponseEntity<Map<String, String>> login(
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String captchaId,
            @RequestParam String captcha,
            HttpServletRequest request) {

        // Directly get IP Address from the request
        String ipAddress = request.getRemoteAddr();

        LOGGER.info("Login attempt for user: {} from IP Address: {}", username, ipAddress);
        Map<String, String> response = new HashMap<>();

        if (!isCaptchaValid(captchaId, captcha)) {
            return createBadRequestResponse("CAPTCHA is invalid.");
        }

        // User user = new User(0, "", "", username);
        // UserSecurity userSecurity = userSecurityService.getUserSecurity(user);

        UserSecurity userSecurity = userSecurityService.getUserSecurity(new User(0, "", "", username));

        if (userSecurity.isLockedOut()) {
            // return handleLockout(userSecurity, username);
            LOGGER.warn("Account locked for user: {} from IP Address: {} due to Invalid credentials.", username,
                    ipAddress);
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error",
                            "Account locked due to multiple failed attempts. Please try again after 60 seconds."));
        }

        if (!isPasswordLengthValid(password)) {
            return createBadRequestResponse("Password must be at least 3 characters long.");
        }

        try {
            authenticateUser(username, password, userSecurity, ipAddress);
            return sendOtpAndPrepareResponse(username, password);
        } catch (AuthenticationException e) {
            return handleInvalidCredentials();
        } catch (NamingException e) {
            return handleNamingException(e);
        } catch (Exception e) {
            return handleUnexpectedException(e);
        }
    }

    @PostMapping("/verifyOtp")
    @ResponseBody
    public ResponseEntity<Map<String, String>> verifyOtp(
            @CookieValue(name = "userKey", required = true) String userKeyCookie,
            @CookieValue(name = "username", required = true) String usernameCookie,
            @RequestParam String username,
            @RequestParam String key,
            @RequestParam String otp,
            HttpServletRequest request) {
        // Directly get IP Address from the request
        String ipAddress = request.getRemoteAddr();

        LOGGER.info("OTP verification attempt for user: {} from IP Address: {} ", username, ipAddress);

        UserSecurity otpSecurity = userSecurityService.getUserSecurity(new User(-1, "", "", username));

        if (otpSecurity.isOtpLockedOut()) {
            LOGGER.warn("Account locked for user: {} from IP Address: {} due to multiple failed OTP attempts.",
                    username, ipAddress);
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error",
                            "Account locked due to multiple failed OTP attempts. Please try again after 60 seconds."));
        }

        String decryptedUsername;
        try {
            decryptedUsername = encryptionUtilsService.decrypt(usernameCookie);
            if (decryptedUsername == null || decryptedUsername.isEmpty()) {
                LOGGER.error("Decryption failed or returned an empty username.");
                return ResponseEntity.badRequest().body(Map.of("error", "Decryption error."));
            }
        } catch (Exception e) {
            LOGGER.error("Error during decryption: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", "Decryption error."));
        }

        int otpKey;
        try {
            otpKey = Integer.parseInt(otp);
        } catch (NumberFormatException e) {
            LOGGER.error("Invalid OTP format: {} from IP Address: {}", otp, ipAddress);
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid OTP format."));
        }

        String secretKey = CsvManagerService.getSecretKey(decryptedUsername);
        if (secretKey == null || secretKey.isEmpty()) {
            LOGGER.error("No secret key found for username: {}", decryptedUsername);
            return ResponseEntity.badRequest().body(Map.of("error", "User not found."));
        }

        boolean isVerified = new GoogleAuthenticator().authorize(secretKey, otpKey);

        if (isVerified) {
            otpSecurity.handleSuccessfulOtp();
            LOGGER.info("OTP verification succeeded for user: {} from IP Address: {}", decryptedUsername, ipAddress);

            // Prepare parameters for redirection
            String exchangeIp = getExchangeIp();
            String encryptedUsername = encryptionUtilsService.encrypt(decryptedUsername);
            String encryptedPassword = encryptionUtilsService.encrypt(encryptionUtilsService.decrypt(userKeyCookie));
            String encryptedExchangeIp = encryptionUtilsService.encrypt(exchangeIp);

            // Set cookies
            ResponseCookie usernameCookieOTP = ResponseCookie.from("username", encryptedUsername).path("/").build();
            ResponseCookie passwordCookie = ResponseCookie.from("password", encryptedPassword).path("/").build();
            ResponseCookie exchangeIpCookie = ResponseCookie.from("exchangeIp", encryptedExchangeIp).path("/").build();

            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.SET_COOKIE, usernameCookieOTP.toString());
            headers.add(HttpHeaders.SET_COOKIE, passwordCookie.toString());
            headers.add(HttpHeaders.SET_COOKIE, exchangeIpCookie.toString());

            // Respond with redirect URL
            return ResponseEntity.ok().headers(headers).body(Map.of("redirect", "/autoLogin"));
        } else {
            otpSecurity.handleFailedOtp();
            LOGGER.warn("Invalid OTP for user: {} from IP Address: {}", decryptedUsername, ipAddress);
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid OTP"));
        }
    }

    private void loadLdapConfiguration() {
        try {
            List<String[]> data = CsvManagerService.getConfiguration();
            if (data == null || data.size() < 3) {
                throw new Exception("Configuration file is missing or corrupt.");
            }
            principalName = data.get(0)[1];
            ldapUrl = data.get(1)[1];
            domain = data.get(2)[1];

            if (ldapUrl == null || ldapUrl.isEmpty() || principalName == null || principalName.isEmpty()) {
                throw new Exception("LDAP URL or principal name is not configured properly.");
            }
            LOGGER.info("LDAP configuration loaded successfully.");
        } catch (Exception e) {
            LOGGER.error("Error loading LDAP configuration: {}", e.getMessage());
            throw new RuntimeException("Failed to load LDAP configuration.", e);
        }
    }

    private void initializeLdapContext() {
        try {
            Hashtable<String, Object> env = new Hashtable<>();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            env.put(Context.PROVIDER_URL, ldapUrl);
            env.put(Context.SECURITY_AUTHENTICATION, "simple");
            env.put(Context.SECURITY_PRINCIPAL, principalName);
            env.put(Context.SECURITY_CREDENTIALS, "");

            ldapContext = new InitialDirContext(env);
            LOGGER.info("LDAP context initialized successfully.");
        } catch (NamingException e) {
            LOGGER.error("Error initializing LDAP context: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to initialize LDAP context.", e);
        }
    }

    private boolean isCaptchaValid(String captchaId, String captcha) {
        boolean isValid = captchaService.verifyCaptcha(captchaId, captcha);
        // LOGGER.info("CAPTCHA validity check for CAPTCHA ID {}: {}", captchaId,
        // isValid);
        return isValid;
    }

    private boolean isPasswordLengthValid(String password) {
        return password.length() >= 3;
    }

    private ResponseEntity<Map<String, String>> createBadRequestResponse(String errorMessage) {
        LOGGER.warn("Bad request: {}", errorMessage);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("error", errorMessage));
    }

    private void authenticateUser(String username, String password, UserSecurity user, String ipAddress)
            throws AuthenticationException, NamingException {
        if ("zaim.k.abbasi@gmail.com".equals(username) && "nadra@123".equals(password)) {
            LOGGER.info("Local authentication succeeded for user: {} from IP Address: {}", username, ipAddress);
            user.handleSuccessfulLogin();
            return;
        } else {
            user.handleFailedLogin();
            throw new AuthenticationException("Invalid username or password.");
        }

        // if (ldapContext == null) {
        // throw new NamingException("LDAP context is not initialized.");
        // }

        // Hashtable<String, Object> env = new Hashtable<>();
        // env.put(Context.SECURITY_AUTHENTICATION, "simple");
        // env.put(Context.SECURITY_PRINCIPAL, principalName + "\\" + username);
        // env.put(Context.SECURITY_CREDENTIALS, password);

        // try {
        // ldapContext.addToEnvironment(Context.SECURITY_PRINCIPAL, principalName + "\\"
        // + username);
        // ldapContext.addToEnvironment(Context.SECURITY_CREDENTIALS, password);
        // LOGGER.info("LDAP authentication succeeded for user: {} from IP Address: {}",
        // username, ipAddress);
        // user.handleSuccessfulLogin();
        // } catch (NamingException e) {
        // LOGGER.error("LDAP authentication failed for user: {} from IP Address: {}.
        // Error: {}", username,ipAddress, e.getMessage());
        // user.handleFailedLogin();
        // throw new AuthenticationException("Invalid username or password.");
        // }
    }

    private String getExchangeIp() {
        List<String[]> data = CsvManagerService.getConfiguration();
        return data.get(3)[1];
    }

    private ResponseEntity<Map<String, String>> sendOtpAndPrepareResponse(String username, String password) {

        // username = username + domain;
        OtpService.send(username);

        String encryptedUsername = encryptionUtilsService.encrypt(username);
        String encryptedPassword = encryptionUtilsService.encrypt(password);

        ResponseCookie nameCookie = createCookie("username", encryptedUsername);
        ResponseCookie keyCookie = createCookie("userKey", encryptedPassword);

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.SET_COOKIE, keyCookie.toString());
        headers.add(HttpHeaders.SET_COOKIE, nameCookie.toString());

        // LOGGER.info("OTP sent successfully to user: {}", username);
        return ResponseEntity.ok()
                .headers(headers)
                .body(Map.of("success", "true", "message", "OTP sent successfully. Please enter the OTP."));
    }

    private ResponseCookie createCookie(String name, String value) {
        return ResponseCookie.from(name, value)
                .httpOnly(false)
                .secure(false)
                .sameSite("Strict")
                .path("/")
                .build();
    }

    private ResponseEntity<Map<String, String>> handleInvalidCredentials() {
        LOGGER.warn("Invalid credentials.");
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid username or password."));
    }

    private ResponseEntity<Map<String, String>> handleNamingException(NamingException e) {
        LOGGER.error("NamingException occurred: {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "An error occurred while trying to authenticate."));
    }

    private ResponseEntity<Map<String, String>> handleUnexpectedException(Exception e) {
        LOGGER.error("Unexpected error occurred: {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "An unexpected error occurred."));
    }
}
