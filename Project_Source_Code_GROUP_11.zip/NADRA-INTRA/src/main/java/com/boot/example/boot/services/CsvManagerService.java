package com.boot.example.boot.services;

import com.boot.example.boot.controller.admin.AdminRestController;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class CsvManagerService {

    private static final Logger logger = LoggerFactory.getLogger(CsvManagerService.class);

    // Update the paths
    private static final String CSV_FILE = "users.csv";
    private static final String ADMIN_SETUP_CSV = "admin-setup.csv";

    public static void addUser(String username, String key) {
        try {
            if (getSecretKey(username).isEmpty()) {
                writeUsernameAndKey(username, key);
                logger.info("User \"{}\" added successfully.", username);
            } else {
                logger.warn("Username \"{}\" already exists.", username);
            }
        } catch (IOException e) {
            logger.error("Error adding user: {}", e.getMessage());
        }
    }

    public static boolean userExists(String username) {
        Path filePath = getResourceFilePath(CSV_FILE);
        try (CSVReader reader = new CSVReader(new FileReader(filePath.toFile()))) {
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0 && nextLine[0].equals(username)) {
                    return true;
                }
            }
        } catch (IOException | CsvValidationException e) {
            logger.error("Error reading CSV file: {}", e.getMessage());
        }
        return false;
    }

    public static String getSecretKey(String username) {
        logger.info("Retrieving secret key for username: {}", username);
        Path filePath = getResourceFilePath(CSV_FILE);
        try (CSVReader reader = new CSVReader(new FileReader(filePath.toFile()))) {
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0 && nextLine[0].equals(username)) {
                    String secretKey = nextLine[1];
                    logger.info("Secret key found for username: {} - Key: {}", username, secretKey);
                    return secretKey;
                }
            }
        } catch (IOException | CsvValidationException e) {
            logger.error("Error reading CSV file: {}", e.getMessage());
        }
        logger.info("No key found for username: {}", username);
        return "";
    }

    private static void writeUsernameAndKey(String username, String key) throws IOException {
        Path filePath = getResourceFilePath(CSV_FILE);
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath.toFile(), true))) {
            writer.writeNext(new String[]{username, key});
        }
    }

    private static Path getResourceFilePath(String resourceFileName) {
        try {
            Path filePath = Paths.get(resourceFileName);
            if (Files.notExists(filePath)) {
                Files.createFile(filePath);
            }
            return filePath;
        } catch (IOException e) {
            logger.error("Error obtaining file path: {}", e.getMessage());
            return Paths.get(""); // Return empty path in case of an error
        }
    }

    public static Map<String, String> getAllUsers() {
        Path filePath = getResourceFilePath(CSV_FILE);
        Map<String, String> users = new HashMap<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath.toFile()))) {
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 1) {
                    users.put(nextLine[0], nextLine[1]);
                }
            }
        } catch (IOException | CsvValidationException e) {
            logger.error("Error processing CSV file: {}", e.getMessage());
        }
        return users;
    }

    public static boolean deleteUserByKey(String userEmail) {
        Path filePath = getResourceFilePath(CSV_FILE);
        try (CSVReader reader = new CSVReader(new FileReader(filePath.toFile()))) {
            List<String[]> data = new ArrayList<>();
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0 && !nextLine[0].equals(userEmail)) {
                    data.add(nextLine);
                }
            }
            writeCSV(filePath, data);
        } catch (IOException | CsvValidationException e) {
            logger.error("Error deleting user: {}", e.getMessage());
            return false;
        }

        String qrCodeImagePath = AdminRestController.getQRCodeImagePath(userEmail);
        File qrCodeImage = new File(qrCodeImagePath);
        if (qrCodeImage.exists()) {
            if (qrCodeImage.delete()) {
                logger.info("QR code image deleted successfully for user: {}", userEmail);
            } else {
                logger.warn("Failed to delete QR code image for user: {}", userEmail);
            }
        } else {
            logger.warn("QR code image does not exist for user: {}", userEmail);
        }

        return true;
    }

    public static List<String[]> getConfiguration() {
        Path filePath = getResourceFilePath(ADMIN_SETUP_CSV);
        try {
            return readCSV(new InputStreamReader(new FileInputStream(filePath.toFile())));
        } catch (IOException | CsvValidationException e) {
            logger.error("Error reading configuration: {}", e.getMessage());
            return new ArrayList<>();
        }
    }

    public static void updateConfiguration(String principalName, String ldapUrl, String domain, String exchangeIp,
                                            String password) {
        Path filePath = getResourceFilePath(ADMIN_SETUP_CSV);

        try {
            List<String[]> data = readCSV(new InputStreamReader(new FileInputStream(filePath.toFile())));

            if (data.size() < 5) {
                logger.warn("Configuration file is missing some required entries.");
                return;
            }

            data.get(0)[1] = principalName;
            data.get(1)[1] = ldapUrl;
            data.get(2)[1] = domain;
            data.get(3)[1] = exchangeIp;
            data.get(4)[1] = password.equals("*****") ? data.get(4)[1] : password;

            writeCSV(filePath, data);

            logger.info("Configuration updated successfully.");
        } catch (IOException | CsvValidationException e) {
            logger.error("Error updating configuration: {}", e.getMessage());
        }
    }

    private static void writeCSV(Path filePath, List<String[]> data) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath.toFile()))) {
            writer.writeAll(data);
        }
    }

    private static List<String[]> readCSV(InputStreamReader streamReader) throws IOException, CsvValidationException {
        List<String[]> data = new ArrayList<>();
        try (CSVReader reader = new CSVReader(streamReader)) {
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                data.add(nextLine);
            }
        }
        return data;
    }
}
