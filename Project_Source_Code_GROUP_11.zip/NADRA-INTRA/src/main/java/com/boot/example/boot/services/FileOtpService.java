package com.boot.example.boot.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

public class FileOtpService {

    private static final Logger logger = LoggerFactory.getLogger(FileOtpService.class);
    private static final String OTP_FILE_PATH = System.getProperty("user.home") + "/aamir-drive/boot/test-otp.txt";

    public String generateOtp(String username) {
        // Generate OTP
        String otp = generateRandomOtp();
        // Save OTP to file
        saveOtpToFile(username, otp);
        return otp;
    }

    private String generateRandomOtp() {
        SecureRandom random = new SecureRandom();
        int otp = 1000 + random.nextInt(9000); // Generates a random 4-digit number
        return String.valueOf(otp);
    }

    private void saveOtpToFile(String username, String otp) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(OTP_FILE_PATH, true))) {
            // Append OTP to the file
            writer.write(username + "=" + otp);
            writer.newLine();
            logger.info("OTP for user '{}' has been saved successfully.", username);
        } catch (IOException e) {
            logger.error("Error saving OTP to file: {}", e.getMessage());
        }
    }

    public boolean verifyOtp(String username, String otp) {
        logger.info("Verifying OTP for user '{}'", username);

        Map<String, String> otpMap = loadOtpFromFile();
        if (otpMap.containsKey(username) && otpMap.get(username).equals(otp)) {
            logger.info("OTP verification successful for user '{}'", username);
            return true;
        }

        logger.warn("OTP verification failed for user '{}'", username);
        return false;
    }

    private Map<String, String> loadOtpFromFile() {
        Map<String, String> otpMap = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(OTP_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts.length == 2) {
                    otpMap.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            logger.error("Error reading OTP file: {}", e.getMessage());
        }
        return otpMap;
    }
}
