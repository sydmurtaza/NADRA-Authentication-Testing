package com.boot.example.boot.controller.admin;

import com.boot.example.boot.User;
import com.boot.example.boot.UserSecurity;
import com.boot.example.boot.services.CsvManagerService;
import com.boot.example.boot.services.EncryptionUtilsService;
import com.boot.example.boot.services.CaptchaService;
import com.boot.example.boot.services.UserSecurityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class AdminLoginController {

    private static final Logger logger = LoggerFactory.getLogger(AdminLoginController.class);

    private final EncryptionUtilsService encryptionUtilsService;
    private final CaptchaService captchaService;
    private final UserSecurityService userSecurityService;

    public AdminLoginController(EncryptionUtilsService encryptionUtilsService, CaptchaService captchaService,
            UserSecurityService userSecurityService) {
        this.encryptionUtilsService = encryptionUtilsService;
        this.captchaService = captchaService;
        this.userSecurityService = userSecurityService;
    }

    @GetMapping("/admin/login")
    public String showLoginPage() {
        logger.info("Rendering admin login page.");
        return "admin/admin-login";
    }

    @PostMapping("/admin-login")
    public ResponseEntity<Map<String, String>> handleLogin(
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String captchaId,
            @RequestParam String captcha, HttpServletRequest request) {

        // Directly get IP Address from the request
        String ipAddress = request.getRemoteAddr();

        logger.info("Login attempt for user: {} from IP Address: {}", username, ipAddress);
        Map<String, String> response = new HashMap<>();

        try {
            if (!captchaService.verifyCaptcha(captchaId, captcha)) {
                logger.warn("Invalid CAPTCHA for user: {} from IP Address: {}", username, ipAddress);
                return createErrorResponse(response, "Invalid CAPTCHA");
            }

            User user = new User(0, "", "", username);
            UserSecurity userSecurity = userSecurityService.getUserSecurity(user);

            if (userSecurity.isLockedOut()) {
                return createLockoutResponse(response, userSecurity, ipAddress);
            }

            String expectedPassword = CsvManagerService.getConfiguration().get(4)[1];
            if (Objects.equals(username, "admin") && Objects.equals(password, expectedPassword)) {
                String encryptedKey = encryptionUtilsService.encrypt(password);
                ResponseCookie keyCookie = ResponseCookie.from("key", encryptedKey)
                        .httpOnly(false)
                        .secure(false)
                        .sameSite("Strict")
                        .path("/")
                        .build();

                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.SET_COOKIE, keyCookie.toString());

                userSecurityService.handleSuccessfulLogin(user);
                response.put("redirect", "/admin");
                logger.info("Login successful for user: {} from IP Address: {}", username, ipAddress);
                return ResponseEntity.ok().headers(headers).body(response);
            }

            userSecurityService.handleFailedLogin(user);
            logger.warn("Invalid credentials for user: {} from IP Address: {}", username, ipAddress);
            return createErrorResponse(response, "Invalid username or password");

        } catch (Exception e) {
            logger.error("Error during login attempt for user: {} from IP Address: {}", username,ipAddress, e);
            return createErrorResponse(response, "Internal server error");
        }
    }

    private ResponseEntity<Map<String, String>> createLockoutResponse(Map<String, String> response,
            UserSecurity userSecurity, String ipAddress) {
        long minutesLeft = Duration.between(LocalDateTime.now(), userSecurity.getLockoutEndTime()).toMinutes();
        String message = minutesLeft < 1
                ? "Account locked for 60 seconds. Try again later."
                : String.format("Account locked for %d minute%s. Try again later.", minutesLeft,
                        minutesLeft > 1 ? "s" : "");

        response.put("error", message);
        logger.warn("User {} is locked out from IP Address: {}. Error: {}", "admin",ipAddress, message);
        return ResponseEntity.badRequest().body(response);
    }

    private ResponseEntity<Map<String, String>> createErrorResponse(Map<String, String> response, String errorMessage) {
        response.put("error", errorMessage);
        return ResponseEntity.badRequest().body(response);
    }
}
