package com.boot.example.boot.controller.admin;

import com.boot.example.boot.services.CsvManagerService;
import com.boot.example.boot.services.EncryptionUtilsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

@RestController
@RequestMapping("/admin")
public class AdminRestController {

    private static final Logger logger = LoggerFactory.getLogger(AdminRestController.class);
    private static final String QR_CODE_DIRECTORY = "qrCode";
    private static final int QR_CODE_SIZE = 300;
    private static final String QR_CODE_FORMAT = "PNG";

    private final EncryptionUtilsService encryptionUtilsService;

    public AdminRestController(EncryptionUtilsService encryptionUtilsService) {
        this.encryptionUtilsService = encryptionUtilsService;
    }

    @GetMapping("/generate-token")
    public ResponseEntity<String> generateToken(@CookieValue(name = "key", required = false) String encryptedKey) {
        logger.info("Token generation request received. Cookie key (masked): {}", maskSensitiveData(encryptedKey));

        if (!isAuthorized(encryptedKey)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access Denied");
        }

        try {
            String newKey = createGoogleAuthKey();
            logger.info("Token generated successfully.");
            return ResponseEntity.ok(newKey);
        } catch (Exception e) {
            logger.error("Error generating token", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error");
        }
    }

    @DeleteMapping("/users/{key}")
    public ResponseEntity<String> deleteUser(@PathVariable String key,
            @CookieValue(name = "key", required = false) String encryptedKey) {
        logger.info("Request to delete user with key: {}. Cookie key (masked): {}", key,
                maskSensitiveData(encryptedKey));

        if (!isAuthorized(encryptedKey)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access Denied");
        }

        boolean userDeleted = CsvManagerService.deleteUserByKey(key);
        if (userDeleted) {
            logger.info("User with key {} deleted successfully.", key);
            return ResponseEntity.ok("User with key " + key + " deleted successfully");
        } else {
            logger.warn("User with key {} not found.", key);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User with key " + key + " not found");
        }
    }

    @GetMapping("/qrcode")
    public ResponseEntity<byte[]> getQRCode(@RequestParam String secret, @RequestParam String username) {
        logger.info("Request for QR code. Username: {}", username);

        try {
            byte[] qrCodeImage = generateQRCodeImage(secret, username);
            logger.info("QR code generated successfully for username: {}", username);
            return ResponseEntity.ok().contentType(org.springframework.http.MediaType.IMAGE_PNG).body(qrCodeImage);
        } catch (WriterException | IOException e) {
            logger.error("Error generating QR code for username: {}", username, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PostMapping("/user/save")
    public ResponseEntity<String> addUserAndSaveQRCode(@CookieValue(name = "key", required = false) String encryptedKey,
            @RequestParam String username, @RequestParam String token) {
        logger.info("Request to add user and save QR code. Username: {}. Cookie key (masked): {}", username,
                maskSensitiveData(encryptedKey));

        if (!isAuthorized(encryptedKey)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access Denied");
        }

        try {
            if (CsvManagerService.userExists(username)) {
                logger.info("User {} already exists.", username);
                return ResponseEntity.badRequest().body("User already exists.");
            }

            CsvManagerService.addUser(username, token);
            saveQRCodeToFile(username, token);

            logger.info("User added and QR Code saved successfully for username: {}", username);
            return ResponseEntity.ok("User added successfully.");
        } catch (Exception e) {
            logger.error("Error adding user and saving QR code for username: {}", username, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error generating QR Code");
        }
    }

    private boolean isAuthorized(String encryptedKey) {
        boolean authorized = encryptionUtilsService.isAuthorized(encryptedKey);
        if (!authorized) {
            logger.warn("Unauthorized access attempt with cookie key: {}", maskSensitiveData(encryptedKey));
        }
        return authorized;
    }

    private String createGoogleAuthKey() {
        GoogleAuthenticator gAuth = new GoogleAuthenticator();
        GoogleAuthenticatorKey credentials = gAuth.createCredentials();
        return credentials.getKey();
    }

    private byte[] generateQRCodeImage(String secret, String username) throws WriterException, IOException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        String qrCodeText = String.format("otpauth://totp/%s?secret=%s&issuer=NADRA INTRA", username, secret);
        BitMatrix bitMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, QR_CODE_SIZE, QR_CODE_SIZE);

        try (ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream()) {
            MatrixToImageWriter.writeToStream(bitMatrix, QR_CODE_FORMAT, pngOutputStream);
            return pngOutputStream.toByteArray();
        }
    }

    private void saveQRCodeToFile(String username, String token) throws WriterException, IOException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        String qrCodeText = String.format("otpauth://totp/%s?secret=%s&issuer=NADRA INTRA", username, token);
        BitMatrix bitMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, QR_CODE_SIZE, QR_CODE_SIZE);

        File directory = new File(QR_CODE_DIRECTORY);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        File qrCodeFile = Paths.get(QR_CODE_DIRECTORY, username + ".png").toFile();
        BufferedImage qrCodeImage = MatrixToImageWriter.toBufferedImage(bitMatrix);
        ImageIO.write(qrCodeImage, QR_CODE_FORMAT, qrCodeFile);
    }

    public static String getQRCodeImagePath(String username) {
        return Paths.get(QR_CODE_DIRECTORY, username + ".png").toString();
    }

    private String maskSensitiveData(String data) {
        return (data == null || data.isEmpty()) ? "N/A" : "****"; // Masked data for security
    }
}
