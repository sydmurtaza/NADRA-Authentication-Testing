package com.boot.example.boot.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service; // Add this import

import javax.net.ssl.*;
import java.net.URI;
import java.security.cert.X509Certificate;

import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;

@Service // Add this annotation
public class OtpService {

    private static final Logger logger = LoggerFactory.getLogger(OtpService.class);

    public static void send(String recipient) {
        try {
            // Trust all certificates
            TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
            };

            // Set the SSL context to trust all certificates
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Set the hostname verifier to allow all hostnames
            HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            // logger.info("SSL context and hostname verifier configured to trust all certificates.");

            // Initialize the Exchange service
            ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP2);

            // Set credentials
            ExchangeCredentials credentials = new WebCredentials("administrator@iampoc", "welcome12345");
            service.setCredentials(credentials);
            // logger.info("Exchange service initialized with provided credentials.");

            // Set the URL of the EWS endpoint using the hostname
            service.setUrl(new URI("https://Exchange/EWS/Exchange.asmx"));
            // logger.info("Exchange service URL set to {}", service.getUrl());

            // // Create a new email message
            // EmailMessage msg = new EmailMessage(service);
            //
            // // Set email properties
            // String otp = new FileOtpService().generateOtp(recipient);
            // msg.setSubject("Test OTP Email");
            // msg.setBody(MessageBody.getMessageBodyFromText(otp));
            // msg.getToRecipients().add(recipient); // aamir.khan@iampoc.com
            // // Send the email
            // msg.send();
            // logger.info("OTP email sent to {}", recipient);

        } catch (Exception e) {
            // logger.error("Error occurred while sending OTP email: {}", e.getMessage());
        }
    }
}
