package com.boot.example.boot.services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@Component
public class EncryptionUtilsService {

    private final String secretKey;

    public EncryptionUtilsService(@Value("${encryption.secret.key}") String secretKey) {
        this.secretKey = secretKey;
    }

    private final String ALGORITHM = "AES";

    public String encrypt(String value) {
        try {
            SecretKeySpec key = new SecretKeySpec(secretKey.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encrypted = cipher.doFinal(value.getBytes());
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception e) {
            System.out.println("Encryption error: " + e.getMessage());
            return null; // Handle error appropriately
        }
    }

    public String decrypt(String encryptedValue) {
        try {
            SecretKeySpec key = new SecretKeySpec(secretKey.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decodedValue = Base64.getDecoder().decode(encryptedValue);
            byte[] decryptedValue = cipher.doFinal(decodedValue);
            return new String(decryptedValue);
        } catch (Exception e) {
            System.out.println("Decryption error: " + e.getMessage());
            return null; // Handle error appropriately
        }
    }

    public boolean isAuthorized(String encryptedKey) {
        if (encryptedKey != null && decrypt(encryptedKey).equals(CsvManagerService.getConfiguration().get(4)[1])) {
            return true;
        }
        return false;
    }

}