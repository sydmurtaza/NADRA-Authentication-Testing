# NADRA INTRA Email Service

## Overview
The NADRA INTRA Email Service is a secure web application designed for internal email communication within NADRA. Developed using Java Spring Boot, this application ensures that only authenticated users can access its features.

## Project Structure
The project adheres to a standard Spring Boot structure and includes the following key components:
- **Controllers**: Handle HTTP requests and responses.
- **Services**: Contain the business logic.
- **Repositories**: Interact with the database.
- **Models**: Define the data structure.
- **Resources**: Include static files, templates, and configuration properties.

## Key Features
- **User Authentication**: Secure login mechanism to authenticate users.
- **QR Code Generation**: Provides QR codes for two-factor authentication.
- **Captcha Verification**: Prevents automated login attempts with captcha verification.
- **CSV Management**: Manages user data stored in CSV files.
- **Session Management**: Automatically logs out users after inactivity and clears cookies and sessions upon tab closure.

## Detailed Functionality

### User Authentication
- Users log in with their credentials.
- Upon successful authentication, users are redirected to the internal email service.
- Two-factor authentication is implemented using QR codes.

### QR Code Generation
- QR codes are created for two-factor authentication using the `QRCodeWriter` class.
- These codes include the OTP (One-Time Password) secret and are shown to users during login.

### Captcha Verification
- Captcha is utilized to prevent automated login attempts.
- The `CaptchaController` and `CaptchaService` manage captcha image generation and verification.

### CSV Management
- User data is stored and managed in CSV files.
- The `CsvManagerService` handles reading from and writing to these CSV files.

### Session Management
- Users are automatically logged out after 10 minutes of inactivity.
- Cookies, sessions, and local storage are cleared when the user closes the tab.

## How to Run the Project

### Prerequisites
- Java 11 or higher
- Maven
- A web browser

### Steps to Run
1. **Clone the Repository:**
   ```bash
   git clone https://github.com/zaim-abbasi/NADRA-INTRA.git
   ```
2. **Build the Project:**
   ```bash
   mvn clean install
   ```
3. **Run the Application:**
   ```bash
   mvn spring-boot:run
   ```
4. **Access the Application:**
   Open your web browser and navigate to [http://localhost:8080](http://localhost:8080).

## Configuration
- Application properties are configured in `src/main/resources/application.properties`.
- Update the properties as needed for your environment.

## Admin Panel
- The admin panel is accessible at [http://localhost:8080/admin](http://localhost:8080/admin).
- Admin functionalities include user management, QR code generation, and system configuration.

## User Login
- Users can log in at [http://localhost:8080/login](http://localhost:8080/login).
- Successful login redirects users to the internal email service.

## Conclusion
The NADRA INTRA Email Service provides a secure and efficient platform for internal email communication at NADRA. It ensures access is restricted to authenticated users and enhances security with two-factor authentication and captcha verification. The application is straightforward to set up and use, making it a valuable tool for NADRA's internal communication needs.

For issues or contributions, please refer to the repository's issue tracker and contribution guidelines.
